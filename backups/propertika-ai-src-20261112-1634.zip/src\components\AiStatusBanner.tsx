import { AlertTriangle, Loader2 } from 'lucide-react';
import type { HealthResponse } from '../types';

interface Props {
  health: HealthResponse | null;
  /** Fitur mana yang dicek kesiapannya: penulisan teks atau pembuatan gambar. */
  capability?: 'text' | 'image';
}

export default function AiStatusBanner({ health, capability = 'text' }: Props) {
  if (!health) {
    return (
      <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-500">
        <Loader2 className="h-4 w-4 animate-spin" />
        Memeriksa status layanan AI...
      </div>
    );
  }

  if (capability === 'image') {
    const provider = health.imageProvider ?? (health.aiEnabled ? 'gemini' : 'none');
    if (provider !== 'none') return null;

    return (
      <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          <strong className="font-semibold">Fitur gambar AI belum aktif.</strong> Isi{' '}
          <code className="rounded bg-white/70 px-1.5 py-0.5 text-xs">CLOUDFLARE_ACCOUNT_ID</code> dan{' '}
          <code className="rounded bg-white/70 px-1.5 py-0.5 text-xs">CLOUDFLARE_API_TOKEN</code> di berkas{' '}
          <code className="rounded bg-white/70 px-1.5 py-0.5 text-xs">.env</code>, lalu jalankan ulang server.
          Pendaftaran Cloudflare gratis dan tidak perlu kartu kredit — kuotanya 10.000 neuron per hari.
        </span>
      </div>
    );
  }

  if (health.aiEnabled) return null;

  return (
    <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
      <span>
        <strong className="font-semibold">GEMINI_API_KEY belum diatur.</strong> Salin berkas{' '}
        <code className="rounded bg-white/70 px-1.5 py-0.5 text-xs">.env.example</code> menjadi{' '}
        <code className="rounded bg-white/70 px-1.5 py-0.5 text-xs">.env</code>, isi kuncinya, lalu jalankan ulang
        server. Selama belum diisi, deskripsi properti memakai draf offline.
      </span>
    </div>
  );
}
