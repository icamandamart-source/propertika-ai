# PROPERTIKA AI

Marketplace properti berbahasa Indonesia dengan akun pengguna dan fitur AI: penulis deskripsi
iklan otomatis, *room makeover*, simulasi rumah di atas tanah kosong, renovasi, dan simulator
furnitur. Dilengkapi kalkulator KPR, pencarian dengan filter, favorit, dan dashboard penjual.

## Menjalankan aplikasi

Butuh **Node.js 20 atau lebih baru**.

```bash
npm install
```

### Mode pengembangan

```bash
npm run dev
```

Buka <http://localhost:3000>. Express memasang Vite sebagai middleware, jadi perubahan berkas
langsung ter-*reload*.

### Mode produksi

```bash
npm run build
npm start
```

`npm run build` memeriksa tipe, membangun antarmuka ke `dist/`, lalu membundel `server.ts`
menjadi `server.js`. `npm start` menyajikan hasil build beserta *fallback* SPA, sehingga alamat
seperti `/properti/seed-1` tetap terbuka saat dimuat ulang langsung.

## Akun dan masuk

Aplikasi memakai **Firebase Authentication**. Halaman yang tersedia:

| Alamat | Isi |
| --- | --- |
| `/daftar` | Daftar dengan email dan kata sandi, atau dengan akun Google |
| `/masuk` | Masuk ke akun yang sudah ada |
| `/lupa-sandi` | Kirim tautan atur ulang kata sandi lewat email |
| `/favorit`, `/dashboard-user`, `/dashboard-seller` | Hanya bisa dibuka setelah masuk |

Halaman terproteksi otomatis mengalihkan ke `/masuk` bila belum masuk, lalu mengembalikan Anda
ke halaman tujuan setelah berhasil masuk.

### Yang perlu dinyalakan di Firebase Console

Konfigurasi bawaan memakai proyek Firebase yang dibuat AI Studio. Saat README ini ditulis,
**provider Email/Password belum aktif** di proyek tersebut, sehingga pendaftaran dan masuk akan
menampilkan pesan bahwa metode itu belum diaktifkan. Supaya bisa dipakai, buka:

1. [Firebase Console](https://console.firebase.google.com/) → pilih proyek → **Authentication**
   → **Sign-in method** → aktifkan **Email/Password** (dan **Google** bila ingin tombol Google).
2. **Authentication** → **Settings** → **Authorized domains** → pastikan `localhost` dan domain
   tempat aplikasi disajikan sudah terdaftar.

Aplikasi akan memberi tahu Anda dengan tepat bila langkah ini belum dilakukan — lengkap dengan
tautan ke halaman pengaturannya.

### Memakai proyek Firebase Anda sendiri

Isi variabel `VITE_FIREBASE_*` di berkas `.env` (lihat `.env.example`). Kalau dikosongkan,
aplikasi memakai `firebase-applet-config.json`. Tanpa konfigurasi sama sekali, aplikasi tetap
bisa dijelajahi; hanya fitur akun yang tidak tersedia.

## Mengaktifkan fitur AI

Fitur AI memakai Google Gemini dan **bersifat opsional**. Tanpa kunci API:

- Deskripsi properti tetap dibuat memakai draf offline (ditandai `source: 'template'`).
- Fitur gambar AI menampilkan pesan bahwa kunci belum diatur.

Cara mengaktifkan:

1. Ambil kunci di <https://aistudio.google.com/apikey>.
2. Salin `.env.example` menjadi `.env`, isi `GEMINI_API_KEY`.
3. Jalankan ulang server.

Isi `.env` yang didukung:

| Variabel | Bawaan | Keterangan |
| --- | --- | --- |
| `GEMINI_API_KEY` | — | Kunci API Google Gemini. |
| `GEMINI_TEXT_MODEL` | `gemini-3.1-flash-lite` | Model untuk penulisan deskripsi. |
| `GEMINI_TEXT_FALLBACKS` | `gemini-3.5-flash-lite,gemini-3-flash-preview` | Model cadangan bila model utama sibuk atau tidak tersedia. |
| `GEMINI_TEXT_TIMEOUT_MS` | `25000` | Batas waktu per model sebelum beralih ke model cadangan. |
| `GEMINI_IMAGE_MODEL` | `gemini-3.1-flash-image` | Model untuk pembuatan gambar. |
| `VITE_FIREBASE_API_KEY` dan kawan-kawan | dari berkas JSON | Konfigurasi Firebase. Lihat `.env.example`. |
| `AI_MINUTE_LIMIT` | `15` | Maksimal permintaan AI per menit per akun. |
| `AI_DAY_LIMIT` | `100` | Maksimal permintaan AI per hari per akun. |
| `PORT` | `3000` | Port server. |

Status fitur AI bisa dicek kapan saja lewat `GET /api/health` (publik).

Semua endpoint AI (`/api/generate-description`, `/api/generate-image`, `/api/analyze-image`)
mewajibkan **ID token Firebase** di header `Authorization: Bearer <idToken>`. Halaman alat AI
juga hanya bisa dibuka setelah masuk, sehingga kuota AI tidak bisa dipakai tanpa akun. Selain
batas per alamat IP (20 permintaan/menit), setiap akun dibatasi `AI_MINUTE_LIMIT` per menit dan
`AI_DAY_LIMIT` per hari; permintaan berlebih dibalas `HTTP 429` beserta pesan yang jelas.

### Penting soal fitur gambar

Model gambar Gemini **tidak tersedia di Free Tier** — kuotanya 0. Selama billing
belum aktif di proyek Google Cloud yang menaungi kunci API, endpoint
`/api/generate-image` akan membalas `HTTP 429` dan aplikasi menampilkan pesan
yang menjelaskan hal ini. Fitur teks (deskripsi properti) tetap berjalan normal
tanpa billing.

Aktifkan billing di <https://console.cloud.google.com/billing>, lalu jalankan
ulang server. Untuk menguji apakah kuota sudah terbuka:

```powershell
curl.exe -s -w "`nHTTP %{http_code}`n" -X POST http://localhost:3000/api/generate-image `
  -H "Content-Type: application/json" -H "Authorization: Bearer <ID_TOKEN_FIREBASE>" `
  -d "{\"mode\":\"room-makeover\",\"prompt\":\"\",\"image\":\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==\"}"
```

`HTTP 200` berarti kuota gambar sudah aktif.

## Perintah lain

| Perintah | Kegunaan |
| --- | --- |
| `npm run typecheck` | Pemeriksaan tipe TypeScript saja. |
| `npm run preview` | Pratinjau hasil build Vite tanpa server Express. |
| `npm run lint` | Alias dari `typecheck`. |

## Struktur proyek

```
server.ts              Server Express: endpoint AI, unggah foto, penyajian berkas, fallback SPA
vite.config.ts         Konfigurasi Vite + Tailwind
index.html             Kerangka HTML
public/                Berkas statis (favicon)
uploads/               Foto listing/pesanan yang diunggah (dibuat otomatis)
src/
  types.ts             Semua tipe bersama dan kontrak API
  App.tsx              Daftar rute
  firebase.ts          Konfigurasi Firebase dan pemuatnya (dimuat belakangan)
  data/seed.ts         Properti contoh dan pemilik fiktifnya
  lib/
    auth.tsx           AuthProvider, useAuth, pesan kesalahan berbahasa Indonesia
    store.ts           Penyimpanan global per akun + localStorage/Firestore
    firestore.ts       Sinkronisasi katalog, akun, dan pesanan ke Firestore
    storage.ts         Unggah foto ke server dan ganti data URL
    ai.ts              Pemanggil endpoint AI
    image.ts           Kompresi gambar, pembuat gambar placeholder
    format.ts          Pemformat rupiah, luas, tanggal
  components/          Komponen antarmuka yang dipakai ulang
  pages/               Satu berkas per halaman
```

## Catatan penting tentang data

Ada dua mode penyimpanan, dipilih lewat `VITE_DATA_BACKEND` di `.env`:

- **Mode lokal (bawaan)** — iklan, favorit, dan pesan disimpan di **localStorage peramban**
  dengan kunci `propertika:v1`, dipisah per akun (`accounts[uid]`). Iklan hanya terlihat di
  peramban tempat iklan itu dipasang.
- **Mode Firestore** (`VITE_DATA_BACKEND=firestore`) — katalog, keranjang, alamat, favorit,
  pesanan, pesan (inquiry), ulasan, dan pengaturan promo/kategori disinkronkan ke Cloud
  Firestore, sehingga terlihat di semua perangkat. Akun tetap ditangani Firebase Authentication.

Pada mode Firestore:

- Foto listing yang diunggah dikirim ke server Express (`POST /api/upload`) dan disimpan di
  folder `uploads/` — bukan ke Firebase Storage, jadi tidak perlu paket Blaze. Server
  memverifikasi ID token Firebase sebelum menerima berkas.
- Folder `uploads/` harus ikut disalin/dipersist saat memindahkan server, dan sebaiknya
  di-backup. Untuk skala produksi, gunakan layanan berkas seperti Firebase Storage/S3.
- **Admin** ditentukan oleh dokumen `admins/{uid}` di Firestore. Admin pertama harus dibuat
  manual dari Firebase Console: buat koleksi `admins`, lalu isi Document ID dengan UID akun
  (lihat Authentication → Users).
- **Pengaturan promo/katalog** (voucher, banner, label kategori, kategori disembunyikan, dan
  override listing) disimpan di dokumen `platform/main`. Semua orang boleh membaca, hanya admin
  yang boleh menulis.
- Aturan keamanan ada di `firestore.rules` dan di-deploy dengan
  `firebase deploy --only firestore:rules`.
- `VITE_FIREBASE_FIRESTORE_DB` menentukan nama database; isi `(default)` untuk database bawaan.

Karena localStorage punya kuota terbatas, gambar yang diunggah diperkecil dan dikompresi di
peramban sebelum disimpan/diunggah.

Tombol **Kosongkan data akun** di dashboard menghapus iklan, favorit, dan pesan milik akun yang
sedang masuk. Akun Firebase-nya sendiri tidak terhapus.

## Sebelum dipakai sungguhan

- Pindahkan penyimpanan foto ke layanan berkas permanen bila server tidak menyimpan disk.
- Perketat aturan keamanan Firestore sebelum menyimpan data sungguhan.
- Kuota dan pembatasan laju masih disimpan di memori: ter-reset saat server dijalankan ulang dan
  tidak dibagi antar-instance. Untuk produksi multi-instance, simpan penghitung di Redis/Firestore.
