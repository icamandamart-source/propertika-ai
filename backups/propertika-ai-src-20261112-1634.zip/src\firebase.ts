/**
 * Konfigurasi dan pemuat Firebase.
 *
 * Modul ini sengaja TIDAK mengimpor paket Firebase secara langsung. Paket
 * `firebase/*` dimuat belakangan lewat `import()` dinamis supaya halaman pertama
 * tetap ringan; pemulihan sesi berjalan di latar belakang setelah aplikasi tampil.
 *
 * Konfigurasi diambil dari variabel lingkungan `VITE_FIREBASE_*` bila ada. Kalau
 * tidak diisi, dipakai nilai bawaan di `firebase-applet-config.json` (proyek yang
 * dibuat AI Studio).
 *
 * Kunci API Firebase untuk aplikasi web memang dirancang untuk terlihat publik —
 * yang melindungi data Anda adalah aturan keamanan Firestore dan daftar domain
 * yang diizinkan di Firebase Console, bukan kerahasiaan kunci ini.
 */
import type { FirebaseApp, FirebaseOptions } from 'firebase/app';
import type { Auth } from 'firebase/auth';
import type { Firestore } from 'firebase/firestore';
import appletConfig from '../firebase-applet-config.json';

const env = import.meta.env;
const applet = appletConfig as Record<string, string | undefined>;

function pick(envValue: string | undefined, fallback: string | undefined): string {
  const trimmed = envValue?.trim();
  return trimmed ? trimmed : (fallback ?? '');
}

export const firebaseConfig: FirebaseOptions = {
  apiKey: pick(env.VITE_FIREBASE_API_KEY, applet.apiKey),
  authDomain: pick(env.VITE_FIREBASE_AUTH_DOMAIN, applet.authDomain),
  projectId: pick(env.VITE_FIREBASE_PROJECT_ID, applet.projectId),
  storageBucket: pick(env.VITE_FIREBASE_STORAGE_BUCKET, applet.storageBucket),
  messagingSenderId: pick(env.VITE_FIREBASE_MESSAGING_SENDER_ID, applet.messagingSenderId),
  appId: pick(env.VITE_FIREBASE_APP_ID, applet.appId),
};

/** Nama basis data Firestore. Boleh kosong untuk memakai basis data bawaan. */
export const firestoreDatabaseId = pick(env.VITE_FIREBASE_FIRESTORE_DB, applet.firestoreDatabaseId);

/** True kalau tiga nilai wajib sudah terisi sehingga Firebase bisa diinisialisasi. */
export const firebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.authDomain && firebaseConfig.projectId,
);

/** Nama domain tempat aplikasi ini disajikan, untuk ditambahkan ke daftar domain yang diizinkan. */
export const currentHost = typeof window === 'undefined' ? '' : window.location.hostname;

/** Tautan langsung ke pengaturan penyedia masuk pada proyek Firebase yang dipakai. */
export const authConsoleUrl = firebaseConfig.projectId
  ? `https://console.firebase.google.com/project/${firebaseConfig.projectId}/authentication/providers`
  : 'https://console.firebase.google.com/';

interface FirebaseBundle {
  app: FirebaseApp;
  auth: Auth;
  db: Firestore;
}

let bundlePromise: Promise<FirebaseBundle | null> | null = null;

async function createBundle(): Promise<FirebaseBundle | null> {
  if (!firebaseConfigured) return null;

  const [{ getApps, initializeApp }, { getAuth }, { getFirestore }] = await Promise.all([
    import('firebase/app'),
    import('firebase/auth'),
    import('firebase/firestore'),
  ]);

  const app = getApps()[0] ?? initializeApp(firebaseConfig);
  // `getFirestore` dengan nama basis data hanya dipakai kalau namanya diisi, supaya
  // konfigurasi proyek lain yang memakai basis data bawaan tetap jalan.
  const db = firestoreDatabaseId ? getFirestore(app, firestoreDatabaseId) : getFirestore(app);

  return { app, auth: getAuth(app), db };
}

/** Muat Firebase sekali saja, lalu pakai hasil yang sama untuk seterusnya. */
export function loadFirebase(): Promise<FirebaseBundle | null> {
  bundlePromise ??= createBundle().catch((error) => {
    // Jangan simpan kegagalan supaya percobaan berikutnya masih bisa berhasil.
    bundlePromise = null;
    throw error;
  });
  return bundlePromise;
}

/** Modul `firebase/auth`, dimuat bersamaan dengan inisialisasi. */
export async function loadAuthModule(): Promise<typeof import('firebase/auth')> {
  return import('firebase/auth');
}
